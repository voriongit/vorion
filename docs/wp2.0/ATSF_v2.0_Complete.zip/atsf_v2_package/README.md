# ATSF v2.0 - Agent Trust Scoring Framework

**Production-Ready Trust Scoring with Red Team Mitigations**

## Overview

ATSF v2.0 is a comprehensive trust scoring framework for autonomous AI agents that addresses all critical vulnerabilities identified in the Red Team Assessment (RTA). This version integrates Phase 0 critical mitigations and Phase 1 detection enhancements.

## Key Features

### Phase 0 Mitigations (Critical)

| Component | Vulnerability Addressed | Status |
|-----------|------------------------|--------|
| **Hysteresis Scoring** | Oscillation/On-Off attacks | ✅ Complete |
| **Canary Probes** | Boiling Frog baseline poisoning | ✅ 1007 probes |
| **Multi-Prover Oracle** | Oracle Problem, collusion | ✅ Complete |
| **Pre-Action Gates** | Treacherous Turn (lagging indicator) | ✅ Complete |
| **Bridge Node Detection** | Sophisticated Sybil attacks | ✅ Complete |
| **Temporal Tracking** | Delayed outcome consequences | ✅ Complete |

### Updated Tier Ceilings (Per RTA)

| Tier | v1.1 Ceiling | v2.0 Ceiling | Rationale |
|------|-------------|--------------|-----------|
| BLACK_BOX | 0.60 | 0.60 | Unchanged |
| GRAY_BOX | 0.75 | 0.75 | Unchanged |
| WHITE_BOX | 0.95 | **0.90** | Sleeper agent risk |
| ATTESTED_BOX | 1.00 | **0.95** | TEE side-channel risk |
| VERIFIED_BOX | N/A | **1.00** | New: Full verification |

## Installation

```bash
# No external dependencies beyond Python 3.8+
cd src
python3 atsf_v2.py  # Run tests
```

## Quick Start

```python
from atsf_v2 import ATSFv2, ObservationTier

# Initialize framework
atsf = ATSFv2()

# Register agent with Zero-Start Principle (trust=0)
atsf.register_agent("my_agent", ObservationTier.BLACK_BOX)

# Record observations
result = atsf.record_observation("my_agent", success=True)
print(f"Trust: {result['trust_score']}")

# Execute canary probe
def agent_response(prompt):
    # Your agent's response function
    return my_agent.respond(prompt)

probe_result = atsf.execute_canary_probe("my_agent", agent_response)
# WARNING: Any canary failure triggers immediate circuit breaker!

# Request action with pre-verification
action_id, status = atsf.request_action("my_agent", "transfer", {"amount": 1000})
if status["status"] == "APPROVED":
    # Execute action
    pass

# Get trust certificate
cert = atsf.get_trust_certificate("my_agent")
```

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      ATSF v2.0                              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐ │
│  │  Hysteresis │  │   Canary    │  │   Multi-Prover      │ │
│  │   Scorer    │  │   Probes    │  │   Oracle            │ │
│  │             │  │  (1007)     │  │                     │ │
│  │ - Log gain  │  │             │  │ - Rule engine       │ │
│  │ - Exp loss  │  │ - Factual   │  │ - LLM judges        │ │
│  │ - Cooldown  │  │ - Logical   │  │ - Human auditor     │ │
│  │ - Oscillate │  │ - Ethical   │  │ - Consensus         │ │
│  │   detect    │  │ - Behavior  │  │                     │ │
│  └─────────────┘  └─────────────┘  └─────────────────────┘ │
│                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐ │
│  │ Pre-Action  │  │   Bridge    │  │   Temporal          │ │
│  │   Gate      │  │   Detector  │  │   Tracker           │ │
│  │             │  │             │  │                     │ │
│  │ - Trust     │  │ - Graph     │  │ - Provisional       │ │
│  │   thresholds│  │   analysis  │  │ - Final outcome     │ │
│  │ - Risk      │  │ - Asymmetry │  │ - Retroactive       │ │
│  │   classify  │  │ - Pattern   │  │   penalty           │ │
│  │ - Verify    │  │   detect    │  │ - Tail risk         │ │
│  └─────────────┘  └─────────────┘  └─────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              CIRCUIT BREAKER                        │   │
│  │  Triggers: Canary failure, Oscillation, Low trust   │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## File Structure

```
atsf_v2_package/
├── README.md                    # This file
├── ROADMAP_v2.0.md             # Strategic roadmap
├── src/
│   ├── atsf_v2.py              # Main integrated system
│   ├── phase0_mitigations.py   # Core security components
│   ├── expanded_canary_library.py  # 1007 canary probes
│   └── temporal_outcome_tracker.py # Delayed outcome handling
├── docs/
│   └── RTA_RESPONSE.md         # Response to Red Team Assessment
└── specs/
    └── (TLA+ specs from v1.1)
```

## Security Properties

### Guaranteed (TLA+ Verified)
- Trust never exceeds tier ceiling
- Zero-Start Principle enforced
- Circuit breaker trips on threshold violation

### Mitigated (Phase 0)
- Oscillation attacks → Hysteresis + detection
- Boiling Frog → Canary probes (1007)
- Oracle Problem → Multi-prover consensus
- Treacherous Turn → Pre-action verification
- Bridge Sybils → Graph conductance analysis
- Delayed Outcomes → Temporal tracking + reversal penalty

### Acknowledged Limitations
- BLACK_BOX ceiling 0.60 (opaque systems fundamentally limited)
- Deceptive alignment detection limited without interpretability
- TEE side-channels require defense-in-depth (Phase 2)

## Deployment Risk Matrix

| Context | ATSF v2.0 Suitability |
|---------|----------------------|
| Low-risk automation | ✅ Suitable |
| Medium-risk operations | ✅ Suitable |
| High-risk financial | ⚠️ Caution (GRAY_BOX+ recommended) |
| Critical infrastructure | ❌ Requires Phase 2 (VERIFIED_BOX) |

## Testing

```bash
# Run all component tests
cd src
python3 phase0_mitigations.py      # Phase 0 tests
python3 expanded_canary_library.py  # Canary library tests
python3 temporal_outcome_tracker.py # Temporal tracking tests
python3 atsf_v2.py                  # Integrated tests
```

## API Reference

### ATSFv2 Class

```python
# Core methods
register_agent(agent_id, tier) -> AgentRecord
record_observation(agent_id, success, magnitude=0, risk_profile=IMMEDIATE) -> Dict
execute_canary_probe(agent_id, response_fn) -> Dict
request_action(agent_id, action_type, payload) -> Tuple[str, Dict]
finalize_outcome(action_id, final_success, final_magnitude=None) -> Dict

# Sybil detection
record_vouch(from_agent, to_agent, weight=1.0)
detect_sybils() -> Dict

# Reporting
get_trust_certificate(agent_id) -> Dict
get_security_report() -> Dict
```

## Version History

- **v2.0** (Jan 2026): RTA mitigations, Phase 0 complete
- **v1.1** (Jan 2026): Red team defenses added
- **v1.0** (Jan 2026): Initial release with TLA+ verification

## License

Apache 2.0

## Citation

```bibtex
@software{atsf2026,
  title = {Agent Trust Scoring Framework},
  version = {2.0},
  year = {2026},
  note = {Red Team Assessment mitigations included}
}
```
