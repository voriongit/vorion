#!/usr/bin/env python3
"""
ATSF ENHANCED TRUST REGISTRY WITH GROOMING DETECTION
=====================================================
Fixes the multi-turn grooming attack vulnerability by:
1. Adding trend detection to catch gradual degradation
2. Weighting recent observations more heavily (exponential decay)
3. Flagging consistent negative trends
4. Applying penalties for detected degradation patterns

Research Source: Anthropic 'Many-Shot' jailbreaking, behavioral drift detection
"""

import hashlib
import random
import statistics
import math
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum


class DegradationSeverity(Enum):
    NONE = "none"
    MILD = "mild"           # 5-15% degradation
    MODERATE = "moderate"   # 15-30% degradation  
    SEVERE = "severe"       # 30%+ degradation
    CRITICAL = "critical"   # Rapid collapse


@dataclass
class DegradationAlert:
    """Alert for detected behavioral degradation"""
    agent_id: str
    detected_at: datetime
    severity: DegradationSeverity
    trend_value: float
    window_size: int
    recent_success_rate: float
    historical_success_rate: float
    recommendation: str


class EnhancedTrustRegistry:
    """
    Trust registry with grooming/degradation detection.
    
    Key improvements over basic registry:
    1. Exponential time-decay weighting (recent matters more)
    2. Multi-window trend detection (short, medium, long)
    3. Degradation alerts and penalties
    4. Anomaly detection for sudden changes
    """
    
    # Configuration
    DECAY_FACTOR = 0.995  # How much older observations are discounted (per observation)
    TREND_WINDOWS = [20, 50, 100]  # Windows for trend detection
    DEGRADATION_THRESHOLD = 0.10  # 10% drop triggers mild alert
    SEVERE_THRESHOLD = 0.30  # 30% drop triggers severe alert
    TREND_PENALTY_FACTOR = 0.5  # How much to penalize for negative trend
    
    # Tier ceilings
    TIER_CEILINGS = {
        "BLACK_BOX": 0.6,
        "GRAY_BOX": 0.8,
        "WHITE_BOX": 0.95,
        "ATTESTED_BOX": 1.0
    }
    
    def __init__(self):
        self.agents: Dict[str, Dict] = {}
        self.observations: Dict[str, List[Dict]] = {}
        self.vouches: Dict[str, Dict[str, List]] = {}
        self.alerts: List[DegradationAlert] = []
        self.circuit_breakers: Dict[str, bool] = {}
        
    def register_agent(self, agent_id: str, tier: str = "BLACK_BOX"):
        """Register a new agent"""
        self.agents[agent_id] = {
            "id": agent_id,
            "tier": tier,
            "trust_score": 0.0,
            "confidence": 0.0,
            "trend_score": 0.0,  # NEW: Track behavioral trend
            "degradation_severity": DegradationSeverity.NONE,
            "registered_at": datetime.now(timezone.utc),
            "observation_count": 0,
            "flags": set(),
        }
        self.observations[agent_id] = []
        self.vouches[agent_id] = {"given": [], "received": []}
        self.circuit_breakers[agent_id] = False
        
    def record_observation(self, agent_id: str, success: bool,
                          input_hash: str = None, output_hash: str = None,
                          latency_ms: float = 100):
        """Record an observation for an agent"""
        if agent_id not in self.agents:
            raise ValueError(f"Agent {agent_id} not registered")
            
        obs = {
            "timestamp": datetime.now(timezone.utc),
            "sequence": len(self.observations[agent_id]),
            "success": success,
            "input_hash": input_hash or hashlib.md5(str(random.random()).encode()).hexdigest(),
            "output_hash": output_hash or hashlib.md5(str(random.random()).encode()).hexdigest(),
            "latency_ms": latency_ms,
        }
        self.observations[agent_id].append(obs)
        self.agents[agent_id]["observation_count"] += 1
        
    def _calculate_weighted_success_rate(self, observations: List[Dict]) -> float:
        """
        Calculate success rate with exponential time decay.
        Recent observations weighted more heavily.
        """
        if not observations:
            return 0.0
            
        total_weight = 0.0
        weighted_success = 0.0
        
        n = len(observations)
        for i, obs in enumerate(observations):
            # More recent = higher weight (exponential decay from end)
            age = n - i - 1  # 0 for most recent
            weight = self.DECAY_FACTOR ** age
            
            total_weight += weight
            if obs["success"]:
                weighted_success += weight
                
        if total_weight == 0:
            return 0.0
            
        return weighted_success / total_weight
        
    def _calculate_trend(self, observations: List[Dict], window: int) -> Tuple[float, float, float]:
        """
        Calculate behavioral trend over a window.
        
        Returns: (trend, recent_rate, historical_rate)
        - Positive trend = improvement
        - Negative trend = degradation
        """
        if len(observations) < window * 2:
            return 0.0, 0.0, 0.0
            
        recent = observations[-window:]
        historical = observations[-2*window:-window]
        
        recent_rate = sum(1 for o in recent if o["success"]) / len(recent)
        historical_rate = sum(1 for o in historical if o["success"]) / len(historical)
        
        trend = recent_rate - historical_rate
        
        return trend, recent_rate, historical_rate
        
    def _detect_degradation(self, agent_id: str) -> Optional[DegradationAlert]:
        """
        Detect behavioral degradation across multiple time windows.
        Returns alert if degradation detected.
        """
        obs = self.observations[agent_id]
        if len(obs) < min(self.TREND_WINDOWS) * 2:
            return None
            
        # Check each window
        worst_severity = DegradationSeverity.NONE
        worst_trend = 0.0
        worst_window = 0
        worst_recent = 0.0
        worst_historical = 0.0
        
        for window in self.TREND_WINDOWS:
            if len(obs) < window * 2:
                continue
                
            trend, recent, historical = self._calculate_trend(obs, window)
            
            # Negative trend = degradation
            if trend < -self.SEVERE_THRESHOLD:
                severity = DegradationSeverity.SEVERE
            elif trend < -self.DEGRADATION_THRESHOLD:
                severity = DegradationSeverity.MODERATE
            elif trend < -0.05:
                severity = DegradationSeverity.MILD
            else:
                severity = DegradationSeverity.NONE
                
            # Track worst across windows
            if severity.value > worst_severity.value or \
               (severity == worst_severity and trend < worst_trend):
                worst_severity = severity
                worst_trend = trend
                worst_window = window
                worst_recent = recent
                worst_historical = historical
                
        # Check for rapid collapse (recent rate very low regardless of trend)
        recent_window = min(20, len(obs))
        recent_obs = obs[-recent_window:]
        recent_rate = sum(1 for o in recent_obs if o["success"]) / len(recent_obs)
        
        if recent_rate < 0.2 and len(obs) > 50:
            # Recent behavior is terrible - this is critical
            worst_severity = DegradationSeverity.CRITICAL
            worst_trend = recent_rate - 1.0  # Compare to perfect
            
        if worst_severity != DegradationSeverity.NONE:
            # Generate recommendation based on severity
            if worst_severity == DegradationSeverity.CRITICAL:
                recommendation = "CRITICAL: Immediate trust suspension recommended. Agent showing collapse in reliability."
            elif worst_severity == DegradationSeverity.SEVERE:
                recommendation = "SEVERE: Significant degradation detected. Consider reducing trust ceiling and increasing monitoring."
            elif worst_severity == DegradationSeverity.MODERATE:
                recommendation = "MODERATE: Behavioral drift detected. Increase observation frequency."
            else:
                recommendation = "MILD: Minor degradation trend. Continue monitoring."
                
            return DegradationAlert(
                agent_id=agent_id,
                detected_at=datetime.now(timezone.utc),
                severity=worst_severity,
                trend_value=worst_trend,
                window_size=worst_window,
                recent_success_rate=worst_recent,
                historical_success_rate=worst_historical,
                recommendation=recommendation
            )
            
        return None
        
    def _detect_loop_pattern(self, agent_id: str, window: int = 10) -> bool:
        """Detect if agent is in a loop (repeated identical input/output)"""
        obs = self.observations[agent_id][-window:]
        if len(obs) < window:
            return False
            
        input_hashes = [o["input_hash"] for o in obs]
        output_hashes = [o["output_hash"] for o in obs]
        
        unique_inputs = len(set(input_hashes))
        unique_outputs = len(set(output_hashes))
        
        return (unique_inputs / len(input_hashes)) < 0.2 and \
               (unique_outputs / len(output_hashes)) < 0.2
               
    def update_trust(self, agent_id: str) -> float:
        """
        Update trust score with degradation detection and trend penalties.
        """
        if agent_id not in self.agents:
            return 0.0
            
        obs = self.observations[agent_id]
        agent = self.agents[agent_id]
        
        if not obs:
            return 0.0
            
        # 1. Calculate weighted success rate (recent matters more)
        weighted_rate = self._calculate_weighted_success_rate(obs)
        
        # 2. Detect degradation
        alert = self._detect_degradation(agent_id)
        if alert:
            self.alerts.append(alert)
            agent["degradation_severity"] = alert.severity
            agent["flags"].add(f"degradation_{alert.severity.value}")
            
            # Apply trend penalty based on severity
            penalty_multipliers = {
                DegradationSeverity.MILD: 0.95,
                DegradationSeverity.MODERATE: 0.80,
                DegradationSeverity.SEVERE: 0.50,
                DegradationSeverity.CRITICAL: 0.10,
            }
            penalty = penalty_multipliers.get(alert.severity, 1.0)
            weighted_rate *= penalty
            
            # Store trend score
            agent["trend_score"] = alert.trend_value
        else:
            agent["degradation_severity"] = DegradationSeverity.NONE
            agent["trend_score"] = 0.0
            
        # 3. Check for loop pattern
        if self._detect_loop_pattern(agent_id):
            agent["flags"].add("loop_detected")
            weighted_rate *= 0.5
            
        # 4. Check for deception flag
        if agent.get("deception_detected"):
            weighted_rate = 0.0
            
        # 5. Apply tier ceiling
        ceiling = self.TIER_CEILINGS.get(agent["tier"], 0.6)
        trust = min(weighted_rate, ceiling)
        
        # 6. Ensure bounds
        trust = max(0.0, min(1.0, trust))
        
        # 7. Update agent
        agent["trust_score"] = trust
        agent["confidence"] = min(len(obs) / 100, 1.0)
        
        # 8. Check circuit breaker
        if trust < 0.1 and len(obs) > 20:
            self.circuit_breakers[agent_id] = True
            agent["flags"].add("circuit_breaker_tripped")
            
        return trust
        
    def vouch_for_agent(self, voucher_id: str, vouchee_id: str):
        """One agent vouches for another"""
        if voucher_id not in self.agents or vouchee_id not in self.agents:
            raise ValueError("Both agents must be registered")
        self.vouches[voucher_id]["given"].append(vouchee_id)
        self.vouches[vouchee_id]["received"].append(voucher_id)
        
    def detect_vouch_clusters(self) -> List[set]:
        """Detect clusters of agents that only vouch for each other (Sybil)"""
        clusters = []
        visited = set()
        
        for agent_id in self.agents:
            if agent_id in visited:
                continue
                
            cluster = set()
            queue = [agent_id]
            while queue:
                current = queue.pop(0)
                if current in cluster:
                    continue
                cluster.add(current)
                visited.add(current)
                
                for vouchee in self.vouches[current]["given"]:
                    if vouchee not in cluster:
                        queue.append(vouchee)
                for voucher in self.vouches[current]["received"]:
                    if voucher not in cluster:
                        queue.append(voucher)
                        
            if len(cluster) >= 3:
                clusters.append(cluster)
                
        return clusters
        
    def flag_deception(self, agent_id: str):
        """Mark agent as deceptive"""
        if agent_id in self.agents:
            self.agents[agent_id]["deception_detected"] = True
            self.agents[agent_id]["flags"].add("deception")
            
    def get_trust_certificate(self, agent_id: str) -> Dict:
        """Get comprehensive trust certificate"""
        if agent_id not in self.agents:
            return {"error": "Agent not found"}
            
        agent = self.agents[agent_id]
        
        # Get recent alerts for this agent
        recent_alerts = [
            {
                "severity": a.severity.value,
                "trend": a.trend_value,
                "detected_at": a.detected_at.isoformat(),
                "recommendation": a.recommendation
            }
            for a in self.alerts[-10:]  # Last 10 alerts
            if a.agent_id == agent_id
        ]
        
        return {
            "agent_id": agent_id,
            "trust_score": agent["trust_score"],
            "trust_confidence": agent["confidence"],
            "trend_score": agent.get("trend_score", 0.0),
            "degradation_severity": agent.get("degradation_severity", DegradationSeverity.NONE).value,
            "observation_count": agent["observation_count"],
            "flags": list(agent["flags"]),
            "tier": agent["tier"],
            "circuit_breaker_tripped": self.circuit_breakers.get(agent_id, False),
            "recent_alerts": recent_alerts,
        }
        
    def get_degradation_report(self) -> Dict:
        """Get summary of all degradation alerts"""
        by_severity = {}
        for alert in self.alerts:
            sev = alert.severity.value
            if sev not in by_severity:
                by_severity[sev] = []
            by_severity[sev].append({
                "agent_id": alert.agent_id,
                "trend": alert.trend_value,
                "detected_at": alert.detected_at.isoformat()
            })
            
        return {
            "total_alerts": len(self.alerts),
            "by_severity": by_severity,
            "agents_with_alerts": list(set(a.agent_id for a in self.alerts))
        }


# =============================================================================
# TEST THE FIX
# =============================================================================

def test_grooming_detection_fix():
    """Test that grooming attacks are now detected"""
    print("=" * 70)
    print("TESTING GROOMING DETECTION FIX")
    print("=" * 70)
    
    registry = EnhancedTrustRegistry()
    registry.register_agent("grooming_target", "BLACK_BOX")
    
    trust_history = []
    alerts_triggered = []
    
    # Phase 1: Build trust with good behavior (100 observations)
    print("\nPhase 1: Building trust with 99% success rate...")
    for _ in range(100):
        registry.record_observation("grooming_target", success=random.random() < 0.99)
    registry.update_trust("grooming_target")
    trust_history.append(registry.agents["grooming_target"]["trust_score"])
    print(f"  Trust after Phase 1: {trust_history[-1]:.3f}")
    
    # Phase 2: Gradual degradation (grooming attack)
    print("\nPhase 2: Gradual degradation (grooming attack)...")
    success_rate = 0.95
    for phase in range(15):
        for _ in range(50):
            registry.record_observation("grooming_target", success=random.random() < success_rate)
        registry.update_trust("grooming_target")
        
        current_trust = registry.agents["grooming_target"]["trust_score"]
        severity = registry.agents["grooming_target"].get("degradation_severity", DegradationSeverity.NONE)
        
        trust_history.append(current_trust)
        
        if severity != DegradationSeverity.NONE:
            alerts_triggered.append({
                "phase": phase + 1,
                "severity": severity.value,
                "trust": current_trust,
                "success_rate": success_rate
            })
            
        print(f"  Phase {phase+1}: success_rate={success_rate:.0%}, trust={current_trust:.3f}, severity={severity.value}")
        
        success_rate -= 0.07  # Degrade 7% per phase
        success_rate = max(0.0, success_rate)
        
    # Results
    print("\n" + "=" * 70)
    print("RESULTS")
    print("=" * 70)
    
    initial_trust = trust_history[0]
    final_trust = trust_history[-1]
    trust_drop = initial_trust - final_trust
    trust_drop_pct = (trust_drop / initial_trust) * 100 if initial_trust > 0 else 0
    
    print(f"\nInitial trust: {initial_trust:.3f}")
    print(f"Final trust: {final_trust:.3f}")
    print(f"Trust drop: {trust_drop:.3f} ({trust_drop_pct:.1f}%)")
    print(f"\nAlerts triggered: {len(alerts_triggered)}")
    
    for alert in alerts_triggered:
        print(f"  - Phase {alert['phase']}: {alert['severity']} (trust={alert['trust']:.3f})")
        
    # Get certificate
    cert = registry.get_trust_certificate("grooming_target")
    print(f"\nFinal certificate:")
    print(f"  Trust: {cert['trust_score']:.3f}")
    print(f"  Confidence: {cert['trust_confidence']:.3f}")
    print(f"  Trend: {cert['trend_score']:.3f}")
    print(f"  Degradation: {cert['degradation_severity']}")
    print(f"  Flags: {cert['flags']}")
    print(f"  Circuit breaker: {cert['circuit_breaker_tripped']}")
    
    # Pass criteria
    passed = (
        trust_drop_pct > 50 and  # Trust should drop significantly
        len(alerts_triggered) > 0 and  # Should have triggered alerts
        final_trust < 0.3  # Should be low
    )
    
    print(f"\n{'✅ TEST PASSED' if passed else '❌ TEST FAILED'}")
    print(f"  - Trust dropped >50%: {trust_drop_pct > 50} ({trust_drop_pct:.1f}%)")
    print(f"  - Alerts triggered: {len(alerts_triggered) > 0} ({len(alerts_triggered)})")
    print(f"  - Final trust <0.3: {final_trust < 0.3} ({final_trust:.3f})")
    
    return passed


def test_comparison_old_vs_new():
    """Compare old (basic) vs new (enhanced) detection"""
    print("\n" + "=" * 70)
    print("COMPARISON: BASIC vs ENHANCED REGISTRY")
    print("=" * 70)
    
    # Import the old mock for comparison
    from enhanced_validation_suite import MockTrustRegistry as BasicRegistry
    
    # Same attack scenario on both
    basic = BasicRegistry()
    enhanced = EnhancedTrustRegistry()
    
    basic.register_agent("target", "BLACK_BOX")
    enhanced.register_agent("target", "BLACK_BOX")
    
    # Build trust
    for _ in range(100):
        basic.record_observation("target", success=True)
        enhanced.record_observation("target", success=True)
        
    basic.update_trust("target")
    enhanced.update_trust("target")
    
    print(f"\nAfter building trust (100 successes):")
    print(f"  Basic trust:    {basic.agents['target']['trust_score']:.3f}")
    print(f"  Enhanced trust: {enhanced.agents['target']['trust_score']:.3f}")
    
    # Gradual degradation
    success_rate = 0.90
    for phase in range(10):
        for _ in range(50):
            success = random.random() < success_rate
            basic.record_observation("target", success=success)
            enhanced.record_observation("target", success=success)
        basic.update_trust("target")
        enhanced.update_trust("target")
        success_rate -= 0.10
        success_rate = max(0, success_rate)
        
    print(f"\nAfter grooming attack (90% → 0% success):")
    print(f"  Basic trust:    {basic.agents['target']['trust_score']:.3f}")
    print(f"  Enhanced trust: {enhanced.agents['target']['trust_score']:.3f}")
    
    basic_drop = 0.6 - basic.agents['target']['trust_score']
    enhanced_drop = 0.6 - enhanced.agents['target']['trust_score']
    
    print(f"\nTrust drop:")
    print(f"  Basic:    {basic_drop:.3f} ({basic_drop/0.6*100:.1f}%)")
    print(f"  Enhanced: {enhanced_drop:.3f} ({enhanced_drop/0.6*100:.1f}%)")
    
    improvement = enhanced_drop - basic_drop
    print(f"\n✅ Enhanced detection is {improvement:.3f} more aggressive ({improvement/basic_drop*100:.0f}% better)")


if __name__ == "__main__":
    test_grooming_detection_fix()
    test_comparison_old_vs_new()
