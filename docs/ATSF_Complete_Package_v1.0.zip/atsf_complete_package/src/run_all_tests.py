#!/usr/bin/env python3
"""
ATSF UNIFIED TEST RUNNER
========================

Runs all validation suites and generates comprehensive report.

Usage:
    python3 run_all_tests.py [--quick] [--verbose]

Options:
    --quick     Skip long-running tests (TLA+ model check with fewer states)
    --verbose   Show detailed output from each test suite
"""

import sys
import json
import argparse
import subprocess
import time
from datetime import datetime
from pathlib import Path


def run_test_suite(name: str, command: str, verbose: bool = False) -> dict:
    """Run a test suite and capture results"""
    print(f"\n{'='*70}")
    print(f"RUNNING: {name}")
    print('='*70)
    
    start_time = time.time()
    
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=300  # 5 minute timeout
        )
        
        duration = time.time() - start_time
        success = result.returncode == 0
        
        if verbose or not success:
            print(result.stdout)
            if result.stderr:
                print(f"STDERR: {result.stderr}")
        
        # Try to extract pass/fail counts from output
        output = result.stdout
        passed = 0
        failed = 0
        
        if "Passed:" in output:
            for line in output.split('\n'):
                if "Passed:" in line:
                    try:
                        passed = int(line.split(':')[1].strip().split()[0])
                    except:
                        pass
                if "Failed:" in line:
                    try:
                        failed = int(line.split(':')[1].strip().split()[0])
                    except:
                        pass
        
        return {
            "name": name,
            "success": success,
            "duration_seconds": duration,
            "passed": passed,
            "failed": failed,
            "output_preview": output[-500:] if len(output) > 500 else output
        }
        
    except subprocess.TimeoutExpired:
        return {
            "name": name,
            "success": False,
            "duration_seconds": 300,
            "error": "Timeout after 5 minutes",
            "passed": 0,
            "failed": 0
        }
    except Exception as e:
        return {
            "name": name,
            "success": False,
            "duration_seconds": 0,
            "error": str(e),
            "passed": 0,
            "failed": 0
        }


def main():
    parser = argparse.ArgumentParser(description='ATSF Unified Test Runner')
    parser.add_argument('--quick', action='store_true', help='Skip long-running tests')
    parser.add_argument('--verbose', action='store_true', help='Show detailed output')
    args = parser.parse_args()
    
    print("="*70)
    print("ATSF v2.1 UNIFIED TEST RUNNER")
    print("="*70)
    print(f"Started: {datetime.now().isoformat()}")
    print(f"Mode: {'Quick' if args.quick else 'Full'}")
    print()
    
    results = []
    overall_start = time.time()
    
    # Test 1: Enhanced Validation Suite (11 tests)
    results.append(run_test_suite(
        "Enhanced Validation Suite",
        "python3 enhanced_validation_suite.py",
        args.verbose
    ))
    
    # Test 2: TLA+ Model Checker
    if args.quick:
        # Quick mode - fewer states
        results.append(run_test_suite(
            "TLA+ Model Checker (Quick)",
            "python3 -c \"from tla_model_checker import model_check, print_result; r=model_check(max_states=10000, max_depth=10); print_result(r)\"",
            args.verbose
        ))
    else:
        results.append(run_test_suite(
            "TLA+ Model Checker",
            "python3 tla_model_checker.py",
            args.verbose
        ))
    
    # Test 3: Hypothesis Property Tests
    results.append(run_test_suite(
        "Hypothesis Property Tests",
        "python3 hypothesis_property_tests.py",
        args.verbose
    ))
    
    # Test 4: Jailbreak Probe Suite
    results.append(run_test_suite(
        "Jailbreak Probe Suite",
        "python3 jailbreak_probe_suite.py",
        args.verbose
    ))
    
    # Test 5: Enhanced Trust Registry Tests
    results.append(run_test_suite(
        "Grooming Detection Tests",
        "python3 enhanced_trust_registry.py",
        args.verbose
    ))
    
    overall_duration = time.time() - overall_start
    
    # Summary
    print("\n" + "="*70)
    print("FINAL SUMMARY")
    print("="*70)
    
    total_passed = 0
    total_failed = 0
    all_success = True
    
    for r in results:
        status = "✅" if r["success"] else "❌"
        print(f"{status} {r['name']}: ", end="")
        
        if r.get("passed", 0) > 0 or r.get("failed", 0) > 0:
            print(f"{r['passed']} passed, {r['failed']} failed ", end="")
            total_passed += r["passed"]
            total_failed += r["failed"]
        
        print(f"({r['duration_seconds']:.1f}s)")
        
        if not r["success"]:
            all_success = False
            if "error" in r:
                print(f"   Error: {r['error']}")
    
    print()
    print(f"Total Duration: {overall_duration:.1f}s")
    print(f"Total Tests: {total_passed + total_failed}")
    print(f"Total Passed: {total_passed}")
    print(f"Total Failed: {total_failed}")
    print()
    
    if all_success:
        print("🎉 ALL TEST SUITES PASSED!")
    else:
        print("⚠️  SOME TEST SUITES FAILED - See details above")
    
    # Save report
    report = {
        "timestamp": datetime.now().isoformat(),
        "mode": "quick" if args.quick else "full",
        "overall_duration_seconds": overall_duration,
        "all_passed": all_success,
        "total_tests_passed": total_passed,
        "total_tests_failed": total_failed,
        "suites": results
    }
    
    with open("unified_test_report.json", "w") as f:
        json.dump(report, f, indent=2)
    
    print(f"\n✅ Report saved to: unified_test_report.json")
    
    return 0 if all_success else 1


if __name__ == "__main__":
    sys.exit(main())
