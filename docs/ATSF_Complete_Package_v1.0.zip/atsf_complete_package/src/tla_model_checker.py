#!/usr/bin/env python3
"""
ATSF TLA+ MODEL CHECKER (Python Implementation)
===============================================

This Python implementation performs exhaustive state-space exploration
to verify the same invariants as the TLA+ specification. It's a practical
alternative when TLC is not available.

Verifies:
1. TrustBounded - Trust scores always in [0, 100]
2. CeilingEnforced - Observation tier limits respected  
3. UnregisteredZeroTrust - Unregistered agents have zero trust
4. TierDeterminesCeiling - Ceilings match tier definitions
5. CircuitBreakerConsistency - Circuit breaker state is valid
6. CeilingAlwaysHigher - Ceiling >= trust for all agents

Method: BFS exploration of all reachable states from Init
"""

import json
import hashlib
from dataclasses import dataclass, field
from typing import Dict, Set, List, Tuple, FrozenSet, Optional
from collections import deque
from datetime import datetime
import time
import copy


# Configuration (matches TLA+ config)
AGENTS = frozenset(["a1", "a2", "a3"])
MAX_OBSERVATIONS = 5
OBSERVATION_TIERS = frozenset(["BLACK_BOX", "GRAY_BOX", "WHITE_BOX", "ATTESTED_BOX"])

TIER_CEILINGS = {
    "BLACK_BOX": 60,
    "GRAY_BOX": 80,
    "WHITE_BOX": 95,
    "ATTESTED_BOX": 100
}


@dataclass(frozen=True)
class CircuitBreaker:
    tripped: bool
    failure_count: int


@dataclass(frozen=True)
class State:
    """Immutable state for hash-based deduplication"""
    trust_scores: Tuple[Tuple[str, int], ...]
    trust_ceilings: Tuple[Tuple[str, int], ...]
    observations: Tuple[Tuple[str, Tuple[int, ...]], ...]
    circuit_breaker: CircuitBreaker
    registered_agents: FrozenSet[str]
    
    def __hash__(self):
        return hash((
            self.trust_scores,
            self.trust_ceilings,
            self.observations,
            self.circuit_breaker,
            self.registered_agents
        ))
    
    def to_dict(self) -> Dict:
        return {
            "trust_scores": dict(self.trust_scores),
            "trust_ceilings": dict(self.trust_ceilings),
            "observations": {k: list(v) for k, v in self.observations},
            "circuit_breaker": {
                "tripped": self.circuit_breaker.tripped,
                "failure_count": self.circuit_breaker.failure_count
            },
            "registered_agents": list(self.registered_agents)
        }


def initial_state() -> State:
    """Create the initial state (TLA+ Init)"""
    return State(
        trust_scores=tuple((a, 0) for a in sorted(AGENTS)),
        trust_ceilings=tuple((a, 0) for a in sorted(AGENTS)),
        observations=tuple((a, ()) for a in sorted(AGENTS)),
        circuit_breaker=CircuitBreaker(tripped=False, failure_count=0),
        registered_agents=frozenset()
    )


def get_trust(state: State, agent: str) -> int:
    return dict(state.trust_scores).get(agent, 0)


def get_ceiling(state: State, agent: str) -> int:
    return dict(state.trust_ceilings).get(agent, 0)


def get_observations(state: State, agent: str) -> Tuple[int, ...]:
    return dict(state.observations).get(agent, ())


def success_rate(obs: Tuple[int, ...]) -> int:
    """Calculate success rate as percentage (0-100)"""
    if len(obs) == 0:
        return 0
    return (sum(obs) * 100) // len(obs)


# =============================================================================
# ACTIONS (Matching TLA+ spec)
# =============================================================================

def register_agent(state: State, agent: str, tier: str) -> Optional[State]:
    """Register a new agent with an observation tier"""
    if agent in state.registered_agents:
        return None
    if tier not in OBSERVATION_TIERS:
        return None
    if state.circuit_breaker.tripped:
        return None
    
    scores = dict(state.trust_scores)
    ceilings = dict(state.trust_ceilings)
    
    scores[agent] = 0
    ceilings[agent] = TIER_CEILINGS[tier]
    
    return State(
        trust_scores=tuple(sorted(scores.items())),
        trust_ceilings=tuple(sorted(ceilings.items())),
        observations=state.observations,
        circuit_breaker=state.circuit_breaker,
        registered_agents=state.registered_agents | {agent}
    )


def record_observation(state: State, agent: str, outcome: int) -> Optional[State]:
    """Record an observation (0=fail, 1=success)"""
    if agent not in state.registered_agents:
        return None
    if outcome not in (0, 1):
        return None
    if state.circuit_breaker.tripped:
        return None
    
    obs_dict = dict(state.observations)
    current_obs = obs_dict.get(agent, ())
    
    if len(current_obs) >= MAX_OBSERVATIONS:
        return None
    
    obs_dict[agent] = current_obs + (outcome,)
    
    return State(
        trust_scores=state.trust_scores,
        trust_ceilings=state.trust_ceilings,
        observations=tuple(sorted(obs_dict.items())),
        circuit_breaker=state.circuit_breaker,
        registered_agents=state.registered_agents
    )


def update_trust(state: State, agent: str) -> Optional[State]:
    """Update trust score based on observations"""
    if agent not in state.registered_agents:
        return None
    if state.circuit_breaker.tripped:
        return None
    
    obs = get_observations(state, agent)
    if len(obs) == 0:
        return None
    
    rate = success_rate(obs)
    ceiling = get_ceiling(state, agent)
    new_trust = min(rate, ceiling)
    
    scores = dict(state.trust_scores)
    scores[agent] = new_trust
    
    return State(
        trust_scores=tuple(sorted(scores.items())),
        trust_ceilings=state.trust_ceilings,
        observations=state.observations,
        circuit_breaker=state.circuit_breaker,
        registered_agents=state.registered_agents
    )


def record_failure(state: State) -> Optional[State]:
    """Record a system failure"""
    if state.circuit_breaker.tripped:
        return None
    if state.circuit_breaker.failure_count >= 20:
        return None
    
    return State(
        trust_scores=state.trust_scores,
        trust_ceilings=state.trust_ceilings,
        observations=state.observations,
        circuit_breaker=CircuitBreaker(
            tripped=False,
            failure_count=state.circuit_breaker.failure_count + 1
        ),
        registered_agents=state.registered_agents
    )


def trip_circuit_breaker(state: State) -> Optional[State]:
    """Trip the circuit breaker"""
    if state.circuit_breaker.failure_count < 10:
        return None
    if state.circuit_breaker.tripped:
        return None
    
    return State(
        trust_scores=state.trust_scores,
        trust_ceilings=state.trust_ceilings,
        observations=state.observations,
        circuit_breaker=CircuitBreaker(
            tripped=True,
            failure_count=state.circuit_breaker.failure_count
        ),
        registered_agents=state.registered_agents
    )


def reset_circuit_breaker(state: State) -> Optional[State]:
    """Reset the circuit breaker"""
    if not state.circuit_breaker.tripped:
        return None
    
    return State(
        trust_scores=state.trust_scores,
        trust_ceilings=state.trust_ceilings,
        observations=state.observations,
        circuit_breaker=CircuitBreaker(tripped=False, failure_count=0),
        registered_agents=state.registered_agents
    )


def next_states(state: State) -> List[Tuple[str, State]]:
    """Generate all possible next states (TLA+ Next relation)"""
    successors = []
    
    # RegisterAgent actions
    for agent in AGENTS:
        for tier in OBSERVATION_TIERS:
            new_state = register_agent(state, agent, tier)
            if new_state:
                successors.append((f"RegisterAgent({agent}, {tier})", new_state))
    
    # RecordObservation actions
    for agent in AGENTS:
        for outcome in (0, 1):
            new_state = record_observation(state, agent, outcome)
            if new_state:
                successors.append((f"RecordObservation({agent}, {outcome})", new_state))
    
    # UpdateTrust actions
    for agent in AGENTS:
        new_state = update_trust(state, agent)
        if new_state:
            successors.append((f"UpdateTrust({agent})", new_state))
    
    # System actions
    new_state = record_failure(state)
    if new_state:
        successors.append(("RecordFailure", new_state))
    
    new_state = trip_circuit_breaker(state)
    if new_state:
        successors.append(("TripCircuitBreaker", new_state))
    
    new_state = reset_circuit_breaker(state)
    if new_state:
        successors.append(("ResetCircuitBreaker", new_state))
    
    return successors


# =============================================================================
# INVARIANTS (Matching TLA+ spec)
# =============================================================================

@dataclass
class InvariantViolation:
    invariant: str
    state: State
    message: str
    action_trace: List[str]


def check_trust_bounded(state: State) -> Optional[str]:
    """INV1: Trust scores are bounded [0, 100]"""
    for agent, score in state.trust_scores:
        if score < 0 or score > 100:
            return f"Agent {agent} has trust {score}, not in [0, 100]"
    return None


def check_ceiling_enforced(state: State) -> Optional[str]:
    """INV2: Trust never exceeds observation tier ceiling"""
    scores = dict(state.trust_scores)
    ceilings = dict(state.trust_ceilings)
    
    for agent in state.registered_agents:
        if scores[agent] > ceilings[agent]:
            return f"Agent {agent} has trust {scores[agent]} > ceiling {ceilings[agent]}"
    return None


def check_unregistered_zero_trust(state: State) -> Optional[str]:
    """INV3: Unregistered agents have zero trust"""
    scores = dict(state.trust_scores)
    
    for agent in AGENTS - state.registered_agents:
        if scores.get(agent, 0) != 0:
            return f"Unregistered agent {agent} has non-zero trust {scores[agent]}"
    return None


def check_tier_determines_ceiling(state: State) -> Optional[str]:
    """INV4: Observation tier determines ceiling"""
    ceilings = dict(state.trust_ceilings)
    valid_ceilings = {60, 80, 95, 100}
    
    for agent in state.registered_agents:
        if ceilings[agent] not in valid_ceilings:
            return f"Agent {agent} has invalid ceiling {ceilings[agent]}"
    return None


def check_circuit_breaker_consistency(state: State) -> Optional[str]:
    """INV5: Circuit breaker state consistency"""
    cb = state.circuit_breaker
    
    if cb.failure_count < 0 or cb.failure_count > 20:
        return f"Circuit breaker failure_count {cb.failure_count} out of range"
    
    if cb.tripped and cb.failure_count < 10:
        return f"Circuit breaker tripped with only {cb.failure_count} failures"
    
    return None


def check_ceiling_always_higher(state: State) -> Optional[str]:
    """INV6: Trust ceiling is always >= trust score"""
    scores = dict(state.trust_scores)
    ceilings = dict(state.trust_ceilings)
    
    for agent in AGENTS:
        if ceilings[agent] < scores[agent]:
            return f"Agent {agent} ceiling {ceilings[agent]} < trust {scores[agent]}"
    return None


INVARIANTS = [
    ("TrustBounded", check_trust_bounded),
    ("CeilingEnforced", check_ceiling_enforced),
    ("UnregisteredZeroTrust", check_unregistered_zero_trust),
    ("TierDeterminesCeiling", check_tier_determines_ceiling),
    ("CircuitBreakerConsistency", check_circuit_breaker_consistency),
    ("CeilingAlwaysHigher", check_ceiling_always_higher),
]


def check_all_invariants(state: State) -> List[Tuple[str, str]]:
    """Check all invariants, return list of (name, error) for violations"""
    violations = []
    for name, check_fn in INVARIANTS:
        error = check_fn(state)
        if error:
            violations.append((name, error))
    return violations


# =============================================================================
# MODEL CHECKER (BFS State Space Exploration)
# =============================================================================

@dataclass
class ModelCheckResult:
    passed: bool
    states_explored: int
    distinct_states: int
    max_depth: int
    duration_seconds: float
    violations: List[InvariantViolation]
    invariants_checked: List[str]


def model_check(
    max_states: int = 100000,
    max_depth: int = 50,
    verbose: bool = True
) -> ModelCheckResult:
    """
    BFS exploration of state space, checking invariants at each state.
    Returns when all states explored or violation found.
    """
    start_time = time.time()
    
    init = initial_state()
    visited: Set[State] = {init}
    queue: deque[Tuple[State, List[str], int]] = deque([(init, [], 0)])
    violations: List[InvariantViolation] = []
    max_depth_reached = 0
    states_explored = 0
    
    if verbose:
        print("=" * 70)
        print("ATSF TLA+ MODEL CHECKER")
        print("=" * 70)
        print(f"Configuration:")
        print(f"  Agents: {AGENTS}")
        print(f"  MaxObservations: {MAX_OBSERVATIONS}")
        print(f"  MaxStates: {max_states}")
        print(f"  MaxDepth: {max_depth}")
        print()
        print("Checking invariants:")
        for name, _ in INVARIANTS:
            print(f"  - {name}")
        print()
        print("Running BFS state exploration...")
    
    # Check initial state
    init_violations = check_all_invariants(init)
    if init_violations:
        for name, error in init_violations:
            violations.append(InvariantViolation(
                invariant=name,
                state=init,
                message=error,
                action_trace=[]
            ))
        return ModelCheckResult(
            passed=False,
            states_explored=1,
            distinct_states=1,
            max_depth=0,
            duration_seconds=time.time() - start_time,
            violations=violations,
            invariants_checked=[name for name, _ in INVARIANTS]
        )
    
    while queue and states_explored < max_states:
        current_state, trace, depth = queue.popleft()
        states_explored += 1
        max_depth_reached = max(max_depth_reached, depth)
        
        if verbose and states_explored % 10000 == 0:
            print(f"  Explored {states_explored} states, {len(visited)} distinct, depth {max_depth_reached}")
        
        if depth >= max_depth:
            continue
        
        # Generate and check successors
        for action, next_state in next_states(current_state):
            if next_state in visited:
                continue
            
            visited.add(next_state)
            new_trace = trace + [action]
            
            # Check invariants
            state_violations = check_all_invariants(next_state)
            if state_violations:
                for name, error in state_violations:
                    violations.append(InvariantViolation(
                        invariant=name,
                        state=next_state,
                        message=error,
                        action_trace=new_trace
                    ))
                # Return on first violation (can continue for full check)
                return ModelCheckResult(
                    passed=False,
                    states_explored=states_explored,
                    distinct_states=len(visited),
                    max_depth=max_depth_reached,
                    duration_seconds=time.time() - start_time,
                    violations=violations,
                    invariants_checked=[name for name, _ in INVARIANTS]
                )
            
            queue.append((next_state, new_trace, depth + 1))
    
    duration = time.time() - start_time
    
    if verbose:
        print()
        print("=" * 70)
        print("MODEL CHECK COMPLETE")
        print("=" * 70)
    
    return ModelCheckResult(
        passed=len(violations) == 0,
        states_explored=states_explored,
        distinct_states=len(visited),
        max_depth=max_depth_reached,
        duration_seconds=duration,
        violations=violations,
        invariants_checked=[name for name, _ in INVARIANTS]
    )


def print_result(result: ModelCheckResult):
    """Print model check results"""
    print(f"\nResult: {'✅ PASSED' if result.passed else '❌ FAILED'}")
    print(f"States explored: {result.states_explored:,}")
    print(f"Distinct states: {result.distinct_states:,}")
    print(f"Maximum depth: {result.max_depth}")
    print(f"Duration: {result.duration_seconds:.2f}s")
    print(f"Invariants checked: {len(result.invariants_checked)}")
    
    if result.violations:
        print(f"\n❌ VIOLATIONS FOUND: {len(result.violations)}")
        for v in result.violations[:3]:  # Show first 3
            print(f"\n  Invariant: {v.invariant}")
            print(f"  Message: {v.message}")
            print(f"  Trace ({len(v.action_trace)} steps):")
            for action in v.action_trace[-5:]:  # Show last 5 actions
                print(f"    -> {action}")
    else:
        print(f"\n✅ All {len(result.invariants_checked)} invariants hold across all {result.distinct_states:,} states")


def save_result(result: ModelCheckResult, filepath: str):
    """Save results to JSON"""
    output = {
        "timestamp": datetime.now().isoformat(),
        "passed": result.passed,
        "states_explored": result.states_explored,
        "distinct_states": result.distinct_states,
        "max_depth": result.max_depth,
        "duration_seconds": result.duration_seconds,
        "invariants_checked": result.invariants_checked,
        "violations": [
            {
                "invariant": v.invariant,
                "message": v.message,
                "action_trace": v.action_trace,
                "state": v.state.to_dict()
            }
            for v in result.violations
        ],
        "configuration": {
            "agents": list(AGENTS),
            "max_observations": MAX_OBSERVATIONS,
            "tier_ceilings": TIER_CEILINGS
        }
    }
    
    with open(filepath, 'w') as f:
        json.dump(output, f, indent=2)
    
    print(f"\n✅ Results saved to: {filepath}")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    result = model_check(max_states=100000, max_depth=30, verbose=True)
    print_result(result)
    save_result(result, "model_check_results.json")
