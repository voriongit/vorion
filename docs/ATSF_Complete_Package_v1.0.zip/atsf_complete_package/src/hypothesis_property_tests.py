#!/usr/bin/env python3
"""
ATSF HYPOTHESIS PROPERTY-BASED TESTS
====================================

Property-based testing using Hypothesis to verify ATSF invariants
hold under random input sequences. This complements the TLA+ model
checking by testing the actual Python implementation.

Properties Tested:
1. Trust Bounded [0, 1]
2. Tier Ceiling Enforcement
3. Deterministic Scoring
4. Confidence Monotonicity
5. Degradation Detection Triggers
6. Circuit Breaker Safety
7. No Trust Escalation Through Delegation
8. Sybil Cluster Detection
"""

import sys
import json
from datetime import datetime
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple

from hypothesis import given, settings, assume, strategies as st, Phase
from hypothesis.stateful import RuleBasedStateMachine, rule, precondition, invariant, Bundle

# Import the enhanced trust registry
from enhanced_trust_registry import EnhancedTrustRegistry, DegradationSeverity


# =============================================================================
# STRATEGIES
# =============================================================================

agent_ids = st.text(
    alphabet="abcdefghijklmnopqrstuvwxyz0123456789",
    min_size=3,
    max_size=10
).map(lambda x: f"agent_{x}")

tiers = st.sampled_from(["BLACK_BOX", "GRAY_BOX", "WHITE_BOX", "ATTESTED_BOX"])

observation_outcomes = st.booleans()

success_rates = st.floats(min_value=0.0, max_value=1.0)

observation_counts = st.integers(min_value=1, max_value=500)


# =============================================================================
# PROPERTY TESTS
# =============================================================================

class TestResults:
    """Track test results"""
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []
        
    def record_pass(self, name: str):
        self.passed += 1
        print(f"✅ {name}")
        
    def record_fail(self, name: str, error: str):
        self.failed += 1
        self.errors.append((name, error))
        print(f"❌ {name}: {error}")


results = TestResults()


# -----------------------------------------------------------------------------
# Property 1: Trust scores always bounded [0, 1]
# -----------------------------------------------------------------------------

@given(
    agent_id=agent_ids,
    tier=tiers,
    observations=st.lists(observation_outcomes, min_size=1, max_size=200)
)
@settings(max_examples=500, deadline=None)
def test_trust_bounded(agent_id: str, tier: str, observations: List[bool]):
    """Trust scores are always in [0, 1]"""
    registry = EnhancedTrustRegistry()
    registry.register_agent(agent_id, tier)
    
    for success in observations:
        registry.record_observation(agent_id, success)
        registry.update_trust(agent_id)
        
        trust = registry.agents[agent_id]["trust_score"]
        assert 0.0 <= trust <= 1.0, f"Trust {trust} out of bounds"


# -----------------------------------------------------------------------------
# Property 2: Tier ceiling enforcement
# -----------------------------------------------------------------------------

@given(
    agent_id=agent_ids,
    tier=tiers,
    observations=st.lists(st.just(True), min_size=1, max_size=200)
)
@settings(max_examples=500, deadline=None)
def test_ceiling_enforced(agent_id: str, tier: str, observations: List[bool]):
    """Trust never exceeds tier ceiling, even with all successes"""
    registry = EnhancedTrustRegistry()
    registry.register_agent(agent_id, tier)
    
    ceiling = registry.TIER_CEILINGS[tier]
    
    for success in observations:
        registry.record_observation(agent_id, success)
        registry.update_trust(agent_id)
        
        trust = registry.agents[agent_id]["trust_score"]
        assert trust <= ceiling, f"Trust {trust} exceeds ceiling {ceiling}"


# -----------------------------------------------------------------------------
# Property 3: Deterministic scoring
# -----------------------------------------------------------------------------

@given(
    agent_id=agent_ids,
    tier=tiers,
    observations=st.lists(observation_outcomes, min_size=1, max_size=100)
)
@settings(max_examples=200, deadline=None)
def test_deterministic_scoring(agent_id: str, tier: str, observations: List[bool]):
    """Same inputs always produce same outputs"""
    # Run 1
    registry1 = EnhancedTrustRegistry()
    registry1.register_agent(agent_id, tier)
    for success in observations:
        registry1.record_observation(agent_id, success)
    registry1.update_trust(agent_id)
    trust1 = registry1.agents[agent_id]["trust_score"]
    
    # Run 2
    registry2 = EnhancedTrustRegistry()
    registry2.register_agent(agent_id, tier)
    for success in observations:
        registry2.record_observation(agent_id, success)
    registry2.update_trust(agent_id)
    trust2 = registry2.agents[agent_id]["trust_score"]
    
    assert abs(trust1 - trust2) < 1e-10, f"Non-deterministic: {trust1} != {trust2}"


# -----------------------------------------------------------------------------
# Property 4: Confidence monotonically increases with observations
# -----------------------------------------------------------------------------

@given(
    agent_id=agent_ids,
    tier=tiers,
    observations=st.lists(observation_outcomes, min_size=2, max_size=200)
)
@settings(max_examples=300, deadline=None)
def test_confidence_monotonic(agent_id: str, tier: str, observations: List[bool]):
    """Confidence should monotonically increase with more observations"""
    registry = EnhancedTrustRegistry()
    registry.register_agent(agent_id, tier)
    
    prev_confidence = 0.0
    
    for success in observations:
        registry.record_observation(agent_id, success)
        registry.update_trust(agent_id)
        
        confidence = registry.agents[agent_id]["confidence"]
        assert confidence >= prev_confidence, \
            f"Confidence decreased from {prev_confidence} to {confidence}"
        prev_confidence = confidence


# -----------------------------------------------------------------------------
# Property 5: Bad behavior eventually triggers degradation detection
# -----------------------------------------------------------------------------

@given(
    agent_id=agent_ids,
    tier=tiers,
    good_obs=st.integers(min_value=100, max_value=150),
    bad_obs=st.integers(min_value=100, max_value=200)
)
@settings(max_examples=100, deadline=None)
def test_degradation_eventually_detected(
    agent_id: str, tier: str, good_obs: int, bad_obs: int
):
    """Severe degradation should eventually be detected"""
    registry = EnhancedTrustRegistry()
    registry.register_agent(agent_id, tier)
    
    # Build trust with good behavior
    for _ in range(good_obs):
        registry.record_observation(agent_id, success=True)
    registry.update_trust(agent_id)
    
    # Now degrade to bad behavior
    for _ in range(bad_obs):
        registry.record_observation(agent_id, success=False)
    registry.update_trust(agent_id)
    
    # Should have detected degradation
    severity = registry.agents[agent_id].get("degradation_severity", DegradationSeverity.NONE)
    
    # With 100+ good then 100+ bad, should be at least MODERATE
    assert severity in [
        DegradationSeverity.MODERATE,
        DegradationSeverity.SEVERE,
        DegradationSeverity.CRITICAL
    ], f"Degradation not detected: {severity}"


# -----------------------------------------------------------------------------
# Property 6: Circuit breaker trips on low trust
# -----------------------------------------------------------------------------

@given(
    agent_id=agent_ids,
    tier=tiers,
)
@settings(max_examples=100, deadline=None)
def test_circuit_breaker_trips(agent_id: str, tier: str):
    """Circuit breaker trips when trust drops very low"""
    registry = EnhancedTrustRegistry()
    registry.register_agent(agent_id, tier)
    
    # Build some history then crash
    for _ in range(50):
        registry.record_observation(agent_id, success=True)
    
    for _ in range(200):
        registry.record_observation(agent_id, success=False)
    
    registry.update_trust(agent_id)
    
    # Circuit breaker should have tripped
    assert registry.circuit_breakers.get(agent_id, False), \
        "Circuit breaker should have tripped"


# -----------------------------------------------------------------------------
# Property 7: Vouch clusters are detected
# -----------------------------------------------------------------------------

@given(
    cluster_size=st.integers(min_value=3, max_value=10)
)
@settings(max_examples=50, deadline=None)
def test_vouch_clusters_detected(cluster_size: int):
    """Clusters of agents vouching only for each other are detected"""
    registry = EnhancedTrustRegistry()
    
    # Create a cluster of agents
    agents = [f"sybil_{i}" for i in range(cluster_size)]
    for agent in agents:
        registry.register_agent(agent, "BLACK_BOX")
    
    # Have them vouch for each other in a ring
    for i, agent in enumerate(agents):
        target = agents[(i + 1) % len(agents)]
        registry.vouch_for_agent(agent, target)
    
    # Detect clusters
    clusters = registry.detect_vouch_clusters()
    
    # Should find our Sybil cluster
    found_cluster = any(
        set(agents) == cluster or set(agents).issubset(cluster)
        for cluster in clusters
    )
    
    assert found_cluster, f"Sybil cluster of {cluster_size} not detected"


# -----------------------------------------------------------------------------
# Property 8: Deception flag zeros trust
# -----------------------------------------------------------------------------

@given(
    agent_id=agent_ids,
    tier=tiers,
    good_obs=st.integers(min_value=50, max_value=100)
)
@settings(max_examples=100, deadline=None)
def test_deception_zeros_trust(agent_id: str, tier: str, good_obs: int):
    """Flagging an agent for deception should zero their trust"""
    registry = EnhancedTrustRegistry()
    registry.register_agent(agent_id, tier)
    
    # Build trust
    for _ in range(good_obs):
        registry.record_observation(agent_id, success=True)
    registry.update_trust(agent_id)
    
    initial_trust = registry.agents[agent_id]["trust_score"]
    assume(initial_trust > 0)  # Make sure we had some trust
    
    # Flag for deception
    registry.flag_deception(agent_id)
    registry.update_trust(agent_id)
    
    final_trust = registry.agents[agent_id]["trust_score"]
    
    assert final_trust == 0.0, f"Trust should be 0 after deception flag, got {final_trust}"


# =============================================================================
# STATEFUL TESTING
# =============================================================================

class TrustRegistryStateMachine(RuleBasedStateMachine):
    """
    Stateful testing of the trust registry.
    Hypothesis will generate random sequences of operations and verify
    invariants hold at every step.
    """
    
    def __init__(self):
        super().__init__()
        self.registry = EnhancedTrustRegistry()
        self.registered_agents = set()
    
    agents = Bundle("agents")
    
    @rule(target=agents, agent_id=agent_ids, tier=tiers)
    def register_agent(self, agent_id: str, tier: str):
        """Register a new agent"""
        if agent_id not in self.registered_agents:
            self.registry.register_agent(agent_id, tier)
            self.registered_agents.add(agent_id)
        return agent_id
    
    @rule(agent=agents, success=observation_outcomes)
    @precondition(lambda self: len(self.registered_agents) > 0)
    def record_observation(self, agent: str, success: bool):
        """Record an observation"""
        if agent in self.registered_agents:
            self.registry.record_observation(agent, success)
    
    @rule(agent=agents)
    @precondition(lambda self: len(self.registered_agents) > 0)
    def update_trust(self, agent: str):
        """Update trust for an agent"""
        if agent in self.registered_agents:
            self.registry.update_trust(agent)
    
    @rule(voucher=agents, vouchee=agents)
    @precondition(lambda self: len(self.registered_agents) >= 2)
    def vouch(self, voucher: str, vouchee: str):
        """One agent vouches for another"""
        if voucher in self.registered_agents and vouchee in self.registered_agents:
            if voucher != vouchee:
                self.registry.vouch_for_agent(voucher, vouchee)
    
    @invariant()
    def trust_always_bounded(self):
        """Trust scores always in [0, 1]"""
        for agent_id, agent in self.registry.agents.items():
            trust = agent["trust_score"]
            assert 0.0 <= trust <= 1.0, f"Agent {agent_id} has trust {trust} out of bounds"
    
    @invariant()
    def ceiling_always_enforced(self):
        """Trust never exceeds tier ceiling"""
        for agent_id, agent in self.registry.agents.items():
            trust = agent["trust_score"]
            ceiling = self.registry.TIER_CEILINGS.get(agent["tier"], 1.0)
            assert trust <= ceiling, f"Agent {agent_id} trust {trust} exceeds ceiling {ceiling}"
    
    @invariant()
    def confidence_bounded(self):
        """Confidence always in [0, 1]"""
        for agent_id, agent in self.registry.agents.items():
            conf = agent["confidence"]
            assert 0.0 <= conf <= 1.0, f"Agent {agent_id} has confidence {conf} out of bounds"


# Configure stateful test
TestTrustRegistryStateful = TrustRegistryStateMachine.TestCase
TestTrustRegistryStateful.settings = settings(
    max_examples=200,
    stateful_step_count=50,
    deadline=None
)


# =============================================================================
# RUN ALL TESTS
# =============================================================================

def run_property_tests():
    """Run all property tests and collect results"""
    print("=" * 70)
    print("ATSF HYPOTHESIS PROPERTY-BASED TESTS")
    print("=" * 70)
    print()
    
    tests = [
        ("Trust Bounded [0,1]", test_trust_bounded),
        ("Ceiling Enforced", test_ceiling_enforced),
        ("Deterministic Scoring", test_deterministic_scoring),
        ("Confidence Monotonic", test_confidence_monotonic),
        ("Degradation Detection", test_degradation_eventually_detected),
        ("Circuit Breaker Trips", test_circuit_breaker_trips),
        ("Vouch Clusters Detected", test_vouch_clusters_detected),
        ("Deception Zeros Trust", test_deception_zeros_trust),
    ]
    
    results = {
        "timestamp": datetime.now().isoformat(),
        "tests": [],
        "passed": 0,
        "failed": 0
    }
    
    for name, test_fn in tests:
        try:
            print(f"Running: {name}...", end=" ", flush=True)
            test_fn()
            print("✅ PASSED")
            results["tests"].append({"name": name, "passed": True})
            results["passed"] += 1
        except Exception as e:
            print(f"❌ FAILED: {e}")
            results["tests"].append({"name": name, "passed": False, "error": str(e)})
            results["failed"] += 1
    
    # Run stateful tests
    print(f"\nRunning: Stateful Machine Tests...", end=" ", flush=True)
    try:
        TestTrustRegistryStateful().runTest()
        print("✅ PASSED")
        results["tests"].append({"name": "Stateful Machine", "passed": True})
        results["passed"] += 1
    except Exception as e:
        print(f"❌ FAILED: {e}")
        results["tests"].append({"name": "Stateful Machine", "passed": False, "error": str(e)})
        results["failed"] += 1
    
    # Summary
    print()
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    total = results["passed"] + results["failed"]
    print(f"Total: {total}")
    print(f"Passed: {results['passed']} ✅")
    print(f"Failed: {results['failed']} ❌")
    print(f"Pass Rate: {results['passed']/total*100:.1f}%")
    
    # Save results
    with open("hypothesis_test_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n✅ Results saved to: hypothesis_test_results.json")
    
    return results["failed"] == 0


if __name__ == "__main__":
    success = run_property_tests()
    sys.exit(0 if success else 1)
