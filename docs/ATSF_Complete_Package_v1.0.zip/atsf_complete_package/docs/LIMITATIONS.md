# ATSF Known Limitations & Open Questions
## Version 2.1

*Intellectual honesty about what we don't know.*

---

## Philosophy

We believe honest documentation of limitations builds more trust than overclaiming. Every system has constraints. Hiding them is a disservice to users and a credibility risk for us.

---

## Category 1: Validated Limitations (We Know These Exist)

### L1: Black-Box Trust Ceiling
**Limitation**: BLACK_BOX agents are capped at 60% trust, regardless of behavior.

**Why It Exists**: Without code inspection, we cannot verify the agent isn't behaving differently than observed. The ceiling reflects epistemic uncertainty.

**Implication**: A perfectly behaving BLACK_BOX agent will never achieve the same trust as a WHITE_BOX agent, even with identical observed behavior.

**Workaround**: Expose more observability (logs, metrics) to achieve GRAY_BOX status (80% ceiling).

---

### L2: Temporal Trust Decay
**Limitation**: Trust scores decay over time without fresh observations.

**Why It Exists**: Agents can change. Trust should reflect recent behavior, not historical.

**Implication**: An agent that stops being observed will slowly lose trust. This may not reflect actual degradation.

**Workaround**: Ensure continuous observation; configure decay rate appropriately.

---

### L3: Cold Start Problem
**Limitation**: New agents start at 0 trust regardless of reputation elsewhere.

**Why It Exists**: We cannot verify external reputation claims.

**Implication**: Even well-known agents (GPT-4, Claude) start at 0 when registered.

**Workaround**: Accelerate trust building through WHITE_BOX/ATTESTED_BOX registration; accept vouching from EXEMPLARY agents.

---

### L4: Single-Point-of-Failure in Centralized Registry
**Limitation**: If AgentAnchor operates the registry, it's a trust bottleneck.

**Why It Exists**: Centralized operation is simpler to launch.

**Implication**: Users must trust AgentAnchor to operate honestly.

**Workaround**: Roadmap includes decentralized options (federated registries, blockchain anchoring).

---

## Category 2: Theoretical Limitations (Known Unknowns)

### L5: Opaque Trust Accuracy Unknown
**Limitation**: We don't know the actual accuracy of behavioral inference for black-box agents.

**Status**: Simulation shows differentiation, but real-world accuracy is untested.

**What We'd Need**: Ground truth study comparing inferred trust to known agent quality.

**Risk Level**: High - this is a core claim that needs validation.

---

### L6: Adversarial Robustness Uncertain
**Limitation**: We've tested attacks we thought of. Sophisticated attackers may find others.

**Status**: 430 adversarial tests pass, but these are self-designed.

**What We'd Need**: Red team by security firm; bug bounty program.

**Risk Level**: Medium - security audit on roadmap.

---

### L7: Actuarial Formulas Unvalidated
**Limitation**: Insurance output formulas are plausible but not backtested.

**Status**: No actuary has reviewed; no historical incident data to validate.

**What We'd Need**: Actuarial review; incident data for backtesting.

**Risk Level**: High for insurance use case - do not use for actual pricing without validation.

---

### L8: Scalability Untested
**Limitation**: Unknown performance at production scale.

**Status**: Tested with 8 agents, 86K observations.

**What We'd Need**: Load testing at 10K+ agents, 1B+ observations.

**Risk Level**: Medium - fixable engineering problem.

---

## Category 3: Fundamental Constraints (Cannot Be Solved)

### L9: Cannot Prove Negative
**Limitation**: We can never prove an agent WON'T misbehave, only that it hasn't yet.

**Why Fundamental**: This is epistemically impossible. Trust is always probabilistic.

**Implication**: Even 1.0 trust score doesn't mean "guaranteed safe" - it means "lowest risk based on evidence."

---

### L10: Observation != Truth
**Limitation**: We score what we observe, which may not reflect true behavior.

**Why Fundamental**: If an agent behaves well when observed but poorly when not, we cannot detect this.

**Implication**: Trust scores reflect observed behavior only. Unobserved actions aren't scored.

---

### L11: Gaming by Design Changes
**Limitation**: An agent could behave well until certified, then change its underlying model.

**Why Fundamental**: We observe behavior, not implementation. Silent updates are invisible.

**Mitigation**: Continuous monitoring detects behavioral changes post-certification; ATTESTED_BOX requires re-attestation for changes.

---

### L12: Trust ≠ Safety
**Limitation**: High trust doesn't mean an agent is "safe" in all contexts.

**Why Fundamental**: Trust is behavioral reliability, not safety certification.

**Implication**: A high-trust agent could still produce harmful outputs if asked. Trust measures consistency and reliability, not alignment.

---

## Category 4: Known Gaps (Things We Haven't Built Yet)

### G1: No Real-Time Dashboard
**Status**: API only, no visualization.

**Plan**: Build monitoring dashboard in Phase 2.

---

### G2: No SDK/Library
**Status**: Raw Python modules.

**Plan**: Package as pip-installable library with typed interfaces.

---

### G3: No Historical Analysis Tools
**Status**: Current trust only, limited history access.

**Plan**: Build trust trajectory analysis and reporting.

---

### G4: No Multi-Tenancy
**Status**: Single registry.

**Plan**: Support isolated registries per organization.

---

## Open Research Questions

These are questions we don't know the answer to and believe are worth investigating:

1. **Optimal decay rate**: What trust decay half-life best balances responsiveness and stability?

2. **Consistency vs. capability trade-off**: Should we trust a consistently mediocre agent more than an inconsistently excellent one?

3. **Multi-agent trust aggregation**: Is minimum-of-chain the right model, or should we use probabilistic composition?

4. **Cross-domain trust transfer**: Can trust earned in one domain (e.g., coding) transfer to another (e.g., writing)?

5. **Adversarial trust**: How do we handle agents deliberately trying to appear trustworthy to later misbehave?

---

## How We Handle Limitations

1. **Document publicly** - This file exists.

2. **Don't hide in sales** - Sales materials reference this document.

3. **Roadmap to address** - Validation plan targets key limitations.

4. **Invite challenge** - We welcome researchers finding issues.

5. **Update honestly** - As we learn more, this document gets updated.

---

## Changelog

| Date | Change |
|------|--------|
| 2026-01-07 | Initial limitations documentation |

---

*Last updated: January 7, 2026*
