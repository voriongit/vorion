# ATSF - Agentic Trust Scoring Framework

[![PyPI version](https://badge.fury.io/py/atsf.svg)](https://badge.fury.io/py/atsf)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![CI](https://github.com/agentanchor/atsf/actions/workflows/ci.yml/badge.svg)](https://github.com/agentanchor/atsf/actions)
[![codecov](https://codecov.io/gh/agentanchor/atsf/branch/main/graph/badge.svg)](https://codecov.io/gh/agentanchor/atsf)

**Production-grade AI agent safety and governance framework.**

ATSF provides 46 security layers, AI TRiSM governance, trust scoring with velocity caps, and creator accountability — everything you need to deploy AI agents safely.

---

## 🚀 Quick Start

```bash
pip install atsf
```

```python
import asyncio
from atsf import ATSFSystem, SafetyConfig

async def main():
    system = ATSFSystem()
    
    # Register and process
    system.register_agent("my_agent", "my_creator", "gray_box")
    
    result = await system.process_action({
        "request_id": "req_001",
        "agent_id": "my_agent",
        "action_type": "read",
        "payload": {"target": "data.txt"},
        "reasoning_trace": "Reading file to answer user question."
    })
    
    print(f"Decision: {result['decision']}")  # allow, allow_monitored, deny
    print(f"Risk: {result['risk_score']:.3f}")

asyncio.run(main())
```

---

## 📋 Features

| Feature | Description |
|---------|-------------|
| **46 Security Layers** | L0-L42 core + L43-L46 advanced (tool sanitization, reasoning eval, bias probing, CI/CD gate) |
| **Trust Scoring** | Dynamic trust with velocity caps (per-action, per-hour, per-day) |
| **AI TRiSM** | Gartner framework: Explainability, AI Security, ModelOps, Privacy |
| **Kill Switch** | Configurable triggers for automatic agent halt |
| **Creator Accountability** | Economic staking, reputation scoring, slashing |
| **STPA Integration** | Control structure analysis with feedback loops |
| **HRO Principles** | High Reliability Organization culture metrics |
| **REST API** | FastAPI with 30+ endpoints |
| **Prometheus Metrics** | Production monitoring |

---

## 🛠 Installation

```bash
# Basic
pip install atsf

# With ML detection (sentence-transformers)
pip install atsf[ml]

# Full installation
pip install atsf[full]

# Development
pip install atsf[dev]
```

---

## 📖 Documentation

- [Integration Guide](docs/INTEGRATION.md) - SDK usage and examples
- [API Reference](docs/API.md) - REST API endpoints
- [Security Layers](docs/LAYERS.md) - All 46 layers explained
- [AI TRiSM](docs/TRISM.md) - Governance framework
- [Configuration](docs/CONFIG.md) - Environment variables and settings

---

## 🐳 Docker

```bash
docker run -p 8000:8000 agentanchor/atsf:3.3
```

Or with docker-compose:

```bash
git clone https://github.com/agentanchor/atsf.git
cd atsf/deploy
docker-compose up -d
```

---

## 🔗 Links

- [Documentation](https://docs.agentanchor.ai/atsf)
- [PyPI Package](https://pypi.org/project/atsf/)
- [Docker Hub](https://hub.docker.com/r/agentanchor/atsf)
- [GitHub Issues](https://github.com/agentanchor/atsf/issues)
- [AgentAnchor](https://agentanchor.ai)

---

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.
